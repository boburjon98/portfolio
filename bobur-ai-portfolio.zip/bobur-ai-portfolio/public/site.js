/* Bobur Tukhtamurodov — offline-capable portfolio interactions. No analytics or external APIs. */
(function () {
  'use strict';
  const root = document.getElementById('site-root');
  if (!root) return;
  document.documentElement.classList.add('has-js');
  const copy = {
    navAbout:'Men haqimda', navWork:'Loyihalar', navExpertise:'Ko‘nikmalar', navExperience:'Tajriba', navCerts:'Sertifikatlar', navContact:'Bog‘lanish <span aria-hidden="true">↗</span>', navContactMobile:'Bog‘lanish',
    heroEyebrow:'AI MUHANDISI · TOSHKENT, O‘ZBEKISTON',
    heroTitle:'Sun’iy intellektni<br><span class="headline-gradient">muhandislikka,</span><br>g‘oyani natijaga.',
    heroSubtitle:'Men Bobur To‘xtamurodov — davlat sektori uchun xavfsiz va amaliy sun’iy intellekt tizimlarini ishlab chiqishga ixtisoslashgan AI va Machine Learning muhandisiman.',
    heroPill1:'Lokal AI', heroPill2:'Multimodal tizimlar', heroPill3:'Amaliy muhandislik', exploreWork:'Loyihalarni ko‘rish', heroFoot:'STRATEGIYA. TADQIQOT. MUHANDISLIK. JORIY ETISH.',
    online:'FAOL', systemTag:'// INTELLEKT QATLAMI', inferenceMode:'INFERENS REJIMI', modeValue:'Lokal / nazorat ostida', pipelineLabel:'TIZIM JARAYONI', privacyFirst:'MAXFIYLIK BIRINCHI O‘RINDA',floatTopSmall:'YO‘NALISH',floatTopBig:'Amaliy AI',floatBottomSmall:'TIZIM DIZAYNI',floatBottomBig:'Lokal ustuvor',
    metric1:'Bojxona texnologiyalarida tajriba',metric2:'AiRO qo‘llaydigan tillar',metric3:'Tovarlarning tasnif kodlari',metric4Value:'LOKAL',metric4:'Maxfiylikka yo‘naltirilgan AI',
    indexAbout:'TANISHUV', aboutOverline:'TIZIMLAR ORTIDAGI MUTAXASSIS', aboutTitle:'Modeldan yuqoriga.<br><span class="subtle-title">Real hayotga yaqinroq.</span>',
    aboutP1:'Faoliyatim sun’iy intellekt, korporativ dasturiy ta’minot va davlat xizmatlarini raqamlashtirish kesishmasida. Asosiy maqsadim ilg‘or AI modellarini haqiqiy muammolarni hal qiladigan ishonchli tizimlarga aylantirish.',
    aboutP2:'O‘zbekiston Respublikasi Bojxona qo‘mitasining bosh inspektori sifatida multimodal AI, kompyuter ko‘rishi, lokal LLM infratuzilmasi va xavfsiz joriy etish yo‘nalishidagi muhandislik ishlarida qatnashaman.',aboutRole:'AI va Machine Learning muhandisi · Bosh inspektor',
    indexWork:'TANLANGAN LOYIHALAR',workOverline:'MAQSADLI MUHANDISLIK',workTitle:'Tadqiqotdan<br><span class="subtle-title">amaliy AI tizimlarigacha.</span>',workIntro:'Ommaga ochiq loyihalar va muhandislik yo‘nalishlari. Maxfiy texnik tafsilotlar ataylab keltirilmagan.',
    filterAll:'Barcha loyihalar <span>04</span>',filterMulti:'Multimodal',filterVoice:'Ovozli AI',filterVision:'Kompyuter ko‘rishi',filterInfra:'Infratuzilma',
    p1status:'OMMAVIY PLATFORMA',p1desc:'Matn, rasm va ovoz orqali 10 xonali tovar kodini dastlabki aniqlash, tarif va notarif choralar haqidagi axborotni olish uchun multimodal AI.',
    p2status:'DAVLAT XIZMATI',p2desc:'Xalqaro aeroport yo‘lovchilariga bojxona qoidalarini tushuntiradigan 10 tilda jonli ovozli muloqot qiluvchi aqlli robot.',
    p3status:'TADQIQOT',p3title:'Yuk rentgen-tahlil AI',p3desc:'Rentgen tasvirlari asosida vagon yuklanishini baholash va deklaratsiyadagi ma’lumotlar bilan mosligini o‘rganish bo‘yicha tadqiqot.',
    p4status:'AI INFRATUZILMASI',p4title:'Lokal LLM infratuzilmasi',p4desc:'Nazorat qilinadigan muhitlar uchun lokal til modellari, ma’lumot qidirish zanjirlari va GPU asosidagi inferens tizimlarini muhandislik jihatdan ishlab chiqish.',
    workFootnote:'Loyihalar haqida faqat umumiy tavsiflar berilgan. Tashkilotning ichki ishlanmalari yoki maxfiy tafsilotlari oshkor etilmagan.',
    indexExpertise:'TEXNIK KO‘NIKMALAR',expertiseOverline:'ASOSIY QADRIYAT FAQAT VOSITA EMAS',expertiseTitle:'Sun’iy intellekt<br><span class="subtle-title">ortidagi muhandislik.</span>',expertiseIntro:'Model integratsiyasi, qidiruv, tasvir tahlili, ishonchli tizimlar va mas’uliyatli AI joriy etishga doir amaliy yo‘nalishlar.',
    skill1title:'LLM va generativ AI',skill1desc:'Modellarni ishga tushirish, prompt tizimlari, optimallashtirish va amaliy til texnologiyalari.',
    skill2title:'RAG va bilim tizimlari',skill2desc:'Qidiruv zanjirlari, semantik izlash, sohaga mos javoblar va tuzilmali ma’lumotlar.',
    skill3title:'Kompyuter ko‘rishi',skill3desc:'Tasvirlardan obyektlarni aniqlash, tasniflash, tahlil va amaliy baholash.',
    skill4title:'Xavfsiz AI muhandisligi',skill4desc:'Python servislar, API, GPU inferens, tizim ishonchliligi va ma’lumotlar nazorati.',
    indexExperience:'TAJRIBA VA YONDASHUV',experienceOverline:'MUHANDISLIK VA MAS’ULIYAT UCHRASHGAN JOY',experienceTitle:'Ishlashi uchun.<br><span class="subtle-title">Uzoq xizmat qilishi uchun.</span>',experienceIntro:'Nozik muhitlarda kuchli AI faqat test natijalariga bog‘liq emas. U ishonchlilik, boshqaruv va puxta integratsiyani ham talab qiladi.',
    principle1:'Ma’lumotlar suvereniteti',principle1sub:'Ma’lumot qayerda saqlanishi va qanday uzatilishini boshqarish.',principle2:'Insonga yo‘naltirilgan AI',principle2sub:'Mutaxassisni almashtirish emas, qaror qabul qilishiga ko‘maklashish.',principle3:'Amaliy ishonchlilik',principle3sub:'Ishonchlilik va qo‘llab-quvvatlashni dastlabdan hisobga olish.',
    timelineTitle:'PROFESSIONAL FAOLIYAT',timelineDate1:'HOZIRGI LAVOZIM',timelineJob1:'Bosh inspektor · AI va ML muhandisligi',timelineCompany1:'O‘zbekiston Respublikasi Bojxona qo‘mitasi',timelineDesc1:'AI integratsiyasi, multimodal tizimlar, kompyuter ko‘rishi va xavfsiz joriy etish.',timelineDate2:'2017-YILDAN',timelineJob2:'Bojxona texnologiyalari va raqamlashtirish',timelineCompany2:'O‘zbekiston bojxona tizimi',timelineDesc2:'Jarayonlarni avtomatlashtirish, dasturiy tizimlar va ma’lumotlarga asoslangan faoliyat.',timelineJob3:'Harbiy bojxona instituti',timelineCompany3:'Oliy ta’lim',timelineDesc3:'LinkedIn profilida ko‘rsatilgan ta’lim.',
    indexCerts:'SERTIFIKATLAR',certOverline:'UZLUKSIZ RIVOJLANISH',certTitle:'Doim o‘rganish.<br><span class="subtle-title">Doim yaratish.</span>',certIntro:'AI, davlat boshqaruvida innovatsiya va bojxona faoliyatiga oid tanlangan sertifikatlar.',
    cert1org:'BAA–O‘zbekiston qo‘shma tashabbusi · Tamomlaganlik sertifikati',cert2org:'O‘zbekiston Respublikasi Raqamli texnologiyalar vazirligi',cert3org:'Ishonch, ko‘nikma va innovatsion madaniyat · Raqamli texnologiyalar vazirligi',cert4org:'Jahon bojxona tashkiloti · WCO CLiKC!',
    contactOverline:'AHAMIYATLI LOYIHALARNI BIRGA YARATAYLIK',contactTitle:'Keyingi katta loyiha<br><em>muloqotdan boshlanadi.</em>',contactCopy:'AI muhandisligi, xavfsiz lokal modellar yoki amaliy Machine Learning sizni qiziqtiradimi? Fikr almashamiz.',contactButton:'LinkedIn orqali bog‘lanish',footerRole:'AI VA MACHINE LEARNING MUHANDISI',backTop:'YUQORIGA',footerRights:'Barcha huquqlar himoyalangan.',footerNote:'Shaxsiy portfolio · Faqat ommaviy ma’lumotlar · Rasmiy davlat sayti emas'
  };
  const projectDetails = {
    notarif: {
      en:{category:'01 / MULTIMODAL AI',title:'NOTARIF — Multimodal Commodity Classification',desc:'A public-facing platform that assists users in finding a preliminary 10-digit commodity classification code through product descriptions, images or voice. The identified code can then be used to access relevant tariff and non-tariff information for Uzbekistan.',contribution:'Personal contribution to the AI engineering components as part of the Uzbekistan Customs AI team. The solution combines local language models, computer vision and speech technologies. AI-assisted classification is indicative and does not replace official customs decisions.',link:'Visit NOTARIF'},
      uz:{category:'01 / MULTIMODAL AI',title:'NOTARIF — multimodal tovar tasnifi',desc:'Tovar nomi, rasmi yoki ovozli tavsifi orqali 10 xonali kodni dastlabki aniqlashga ko‘maklashuvchi ommaviy platforma. Kodga mos O‘zbekistondagi tarif va notarif choralari haqidagi axborotni ko‘rsatadi.',contribution:'Bojxona AI jamoasi tarkibida sun’iy intellekt muhandisligi qismida shaxsan qatnashganman. Lokal til modellari, kompyuter ko‘rishi va nutq texnologiyalari birlashtirilgan. AI natijasi dastlabki ko‘mak bo‘lib, rasmiy bojxona qarorini almashtirmaydi.',link:'NOTARIF saytini ochish'},
      tags:['Multimodal AI','LLM','Computer Vision','STT','Local Inference'],url:'https://notarif.customs.uz/notarif/'
    },
    airo: {
      en:{category:'02 / VOICE AI',title:'AiRO — Multilingual Customs Assistant',desc:'AiRO is an interactive voice-enabled customs robot supporting conversations in ten languages. It was designed to help passengers at Tashkent International Airport obtain accessible guidance on customs procedures.',contribution:'Personal contribution to the AI layer within the Customs Committee team, including locally deployed voice and language AI components. The approach avoids dependence on external AI services for sensitive interactions.',link:'View LinkedIn project context'},
      uz:{category:'02 / OVOZLI AI',title:'AiRO — ko‘p tilli bojxona yordamchisi',desc:'AiRO — 10 tilda jonli ovozli suhbatlashadigan interaktiv robot. U Toshkent xalqaro aeroporti yo‘lovchilariga bojxona qoidalarini qulay tushuntirish uchun yaratilgan.',contribution:'Bojxona qo‘mitasi jamoasi tarkibida robotning AI qismida shaxsan qatnashganman. Lokal nutq va til modellari yordamida maxfiy ma’lumotlarni tashqi AI xizmatlariga uzatmaslik yondashuvi qo‘llanilgan.',link:'LinkedIn profilingizda ko‘rish'},
      tags:['Voice AI','Multilingual','LLM','STT','TTS','On-premises'],url:'https://www.linkedin.com/in/bobur-tukhtamurodov-601a45315/'
    },
    xray: {
      en:{category:'03 / COMPUTER VISION RESEARCH',title:'Cargo X-ray Intelligence — Research',desc:'Research into deep-learning approaches for analysing railway cargo X-ray imagery, assessing cargo-area occupancy and identifying findings that may warrant further human review against declarations.',contribution:'Applied computer vision research and evaluation. This is presented as an engineering research direction, not as a claim that an autonomous decision-making system has been deployed.',link:''},
      uz:{category:'03 / KOMPYUTER KO‘RISHI TADQIQOTI',title:'Rentgen tasvirlarini AI asosida tahlil qilish',desc:'Temir yo‘l yuklarining rentgen tasvirlarini chuqur o‘rganish usullari bilan tahlil qilish, yuk maydonining to‘lish darajasini baholash va deklaratsiya bilan tekshirishni talab qilishi mumkin bo‘lgan holatlarni o‘rganish.',contribution:'Kompyuter ko‘rishi bo‘yicha amaliy tadqiqot va baholash. Bu yo‘nalish tadqiqot sifatida ko‘rsatilgan, to‘liq avtonom tizim amaliyotga joriy etilgan degan da’vo qilinmaydi.',link:''},
      tags:['Computer Vision','Deep Learning','X-ray','R&D'],url:null
    },
    infrastructure: {
      en:{category:'04 / AI INFRASTRUCTURE',title:'Local LLM & Retrieval Infrastructure',desc:'Enterprise-focused engineering for deploying language models and retrieval-based systems in controlled environments, with attention to security boundaries, model serving and GPU resource utilisation.',contribution:'Hands-on work with Qwen-family models, vLLM serving, RAG patterns and Qdrant vector retrieval. Sensitive infrastructure details are intentionally excluded.',link:''},
      uz:{category:'04 / AI INFRATUZILMASI',title:'Lokal LLM va ma’lumot qidirish infratuzilmasi',desc:'Til modellari va qidiruvga asoslangan tizimlarni nazorat qilinadigan korporativ muhitlarda ishlatish, xavfsizlik chegaralari, model servis va GPU resurslaridan oqilona foydalanish.',contribution:'Qwen turkumidagi modellar, vLLM, RAG va Qdrant vektorli qidiruvi bilan amaliy ishlar. Ichki infratuzilmaga doir maxfiy ma’lumotlar keltirilmaydi.',link:''},
      tags:['Qwen','vLLM','RAG','Qdrant','GPU Inference'],url:null
    }
  };
  const translationEls = Array.from(root.querySelectorAll('[data-i18n], [data-i18n-html]'));
  const originals = new Map(translationEls.map(el => [el, el.hasAttribute('data-i18n-html') || el.querySelector('span[aria-hidden]') ? el.innerHTML : el.textContent]));
  let lang = 'en';
  function safeGet(key) { try { return localStorage.getItem(key); } catch { return null; } }
  function safeSet(key,value) { try { localStorage.setItem(key,value); } catch {} }
  function setLanguage(next) {
    lang = next === 'uz' ? 'uz' : 'en';
    translationEls.forEach(el => {
      const htmlKey = el.getAttribute('data-i18n-html');
      const key = htmlKey || el.getAttribute('data-i18n');
      if(lang === 'uz' && copy[key]) {
        if (htmlKey || /<span/.test(copy[key])) el.innerHTML = copy[key]; else el.textContent = copy[key];
      } else {
        if (htmlKey || /<span/.test(originals.get(el))) el.innerHTML = originals.get(el);
        else el.textContent = originals.get(el);
      }
    });
    root.querySelector('.lang-label').textContent = lang === 'en' ? 'UZ' : 'EN';
    document.documentElement.lang = lang;
    document.title = lang === 'en' ? 'Bobur Tukhtamurodov | AI & Machine Learning Engineer' : 'Bobur To‘xtamurodov | AI va Machine Learning muhandisi';
    safeSet('bt-language', lang);
  }
  const languageButton = root.querySelector('.language-toggle');
  languageButton.addEventListener('click',()=>setLanguage(lang==='en'?'uz':'en'));
  function setTheme(next) {
    const mode = next === 'light' ? 'light' : 'dark';
    root.dataset.theme = mode;
    root.querySelector('.theme-symbol').textContent = mode === 'dark' ? '☼' : '☾';
    root.querySelector('.theme-toggle').setAttribute('aria-label',mode === 'dark' ? 'Switch to light theme' : 'Switch to dark theme');
    safeSet('bt-theme',mode);
  }
  root.querySelector('.theme-toggle').addEventListener('click',()=>setTheme(root.dataset.theme === 'dark' ? 'light' : 'dark'));
  const menu = root.querySelector('.mobile-nav');
  const menuToggle = root.querySelector('.menu-toggle');
  const toggleMenu = force => {
    const shouldOpen = typeof force === 'boolean' ? force : menu.hidden;
    menu.hidden = !shouldOpen;
    menuToggle.setAttribute('aria-expanded',String(shouldOpen));
    menuToggle.setAttribute('aria-label', shouldOpen ? 'Close navigation' : 'Open navigation');
  };
  menuToggle.addEventListener('click',()=>toggleMenu());
  menu.querySelectorAll('a').forEach(a => a.addEventListener('click',()=>toggleMenu(false)));
  const filters = Array.from(root.querySelectorAll('.filter-chip'));
  const cards = Array.from(root.querySelectorAll('.project-card'));
  filters.forEach(button => button.addEventListener('click',()=>{
    const filter = button.dataset.filter;
    filters.forEach(b=>{const active=b===button;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));});
    cards.forEach(c=>{c.hidden = filter!=='all' && c.dataset.category!==filter;});
  }));
  const overlay=root.querySelector('.modal-backdrop');
  const panel=root.querySelector('.modal-panel');
  const modalLink=root.querySelector('#modal-link');
  let returnFocus=null;
  function openProject(key,source){
    const data=projectDetails[key]; if(!data) return;
    const tr=data[lang];
    root.querySelector('#modal-category').textContent=tr.category;
    root.querySelector('#modal-title').textContent=tr.title;
    root.querySelector('#modal-description').textContent=tr.desc;
    root.querySelector('#modal-contribution-title').textContent=lang==='en'?'Engineering contribution':'Muhandislik hissasi';
    root.querySelector('#modal-contribution').textContent=tr.contribution;
    root.querySelector('#modal-tags').replaceChildren(...data.tags.map(t=>{let x=document.createElement('span');x.textContent=t;return x;}));
    modalLink.hidden=!data.url;
    if(data.url){modalLink.href=data.url;root.querySelector('#modal-link-text').textContent=tr.link;}
    root.querySelector('#modal-close-bottom').firstChild.textContent=lang==='en'?'Close ':'Yopish ';
    returnFocus=source;
    overlay.hidden=false;
    document.body.classList.add('modal-open');
    root.querySelector('.modal-close').focus();
  }
  function closeProject(){overlay.hidden=true;document.body.classList.remove('modal-open');if(returnFocus) returnFocus.focus();}
  cards.forEach(card=>{
    card.addEventListener('click',()=>openProject(card.dataset.project,card));
    card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openProject(card.dataset.project,card);}});
  });
  root.querySelector('.modal-close').addEventListener('click',closeProject);
  root.querySelector('#modal-close-bottom').addEventListener('click',closeProject);
  overlay.addEventListener('click',e=>{if(e.target===overlay)closeProject();});
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape'&&!overlay.hidden)closeProject();
    if(e.key==='Tab'&&!overlay.hidden){
      const items=Array.from(panel.querySelectorAll('a:not([hidden]),button:not([hidden])')).filter(x=>x.offsetParent!==null);
      if(items.length===0)return;
      const first=items[0],last=items[items.length-1];
      if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
      else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
    }
  });
  const revealEls=root.querySelectorAll('.reveal');
  if('IntersectionObserver' in window){
    const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target);}}),{threshold:.07,rootMargin:'0px 0px 55px 0px'});
    revealEls.forEach(el=>observer.observe(el));
  }else revealEls.forEach(el=>el.classList.add('visible'));
  setTheme(safeGet('bt-theme')||'dark');
  setLanguage(safeGet('bt-language')||'en');
})();
